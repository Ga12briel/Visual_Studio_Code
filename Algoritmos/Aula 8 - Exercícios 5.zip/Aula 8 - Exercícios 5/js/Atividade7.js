var c = 2
while (c <= 10) {
  document.write(c)
  c = c + 2
  document.write(" ")
}